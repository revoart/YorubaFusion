import { base44 } from './base44Client';


export const MealPlan = base44.entities.MealPlan;



// auth sdk:
export const User = base44.auth;