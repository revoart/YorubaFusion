
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Apple, Leaf, GlassWater } from 'lucide-react';
import MealCard from './MealCard';

export default function MealPlanDisplay({ plan }) {
  if (!plan) {
    return (
        <div className="text-center p-8">
            <p className="text-gray-500">Loading meal plan...</p>
        </div>
    );
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={plan.day}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
        className="max-w-4xl mx-auto bg-white/30 backdrop-blur-lg p-4 md:p-8 rounded-2xl shadow-lg border border-gray-200/50"
      >
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-6 text-[#4A2A1E]">{plan.day_name}</h2>
        
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6"
        >
          <MealCard title="Breakfast" initialMeal={plan.breakfast} type={plan.breakfast_type} />
          <MealCard title="Lunch" initialMeal={plan.lunch} type={plan.lunch_type} />
          <MealCard title="Dinner" initialMeal={plan.dinner} type={plan.dinner_type} />
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6"
        >
          <div className="bg-white/50 backdrop-blur-md rounded-xl p-4 border border-black/5 flex items-start gap-4">
            <Leaf className="w-6 h-6 text-[#2C5F2D] flex-shrink-0 mt-1" />
            <div>
              <h4 className="font-semibold text-[#4A2A1E]">Appetizer</h4>
              <p className="text-gray-700 text-sm">{plan.appetizer}</p>
            </div>
          </div>
          <div className="bg-white/50 backdrop-blur-md rounded-xl p-4 border border-black/5 flex items-start gap-4">
            <Apple className="w-6 h-6 text-[#E54B1A] flex-shrink-0 mt-1" />
            <div>
              <h4 className="font-semibold text-[#4A2A1E]">Fruits</h4>
              <p className="text-gray-700 text-sm">{plan.fruits}</p>
            </div>
          </div>
          <div className="bg-white/50 backdrop-blur-md rounded-xl p-4 border border-black/5 flex items-start gap-4">
            <GlassWater className="w-6 h-6 text-[#3b82f6] flex-shrink-0 mt-1" />
            <div>
              <h4 className="font-semibold text-[#4A2A1E]">Drinks</h4>
              <p className="text-gray-700 text-sm">{plan.drinks}</p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
