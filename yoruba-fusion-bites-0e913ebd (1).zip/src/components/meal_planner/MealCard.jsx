import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from '@/components/ui/button';
import { RefreshCw, BookOpen, Loader2, Zap } from 'lucide-react';
import RecipeDisplay from './RecipeDisplay';

export default function MealCard({ title, type, initialMeal }) {
  const [currentMeal, setCurrentMeal] = useState(initialMeal);
  const [mealOptions, setMealOptions] = useState([initialMeal]);
  const [recipe, setRecipe] = useState(null);
  const [calories, setCalories] = useState(null);
  const [isRecipeVisible, setIsRecipeVisible] = useState(false);
  const [isLoadingMeals, setIsLoadingMeals] = useState(false);
  const [isLoadingRecipe, setIsLoadingRecipe] = useState(false);
  const [isLoadingCalories, setIsLoadingCalories] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setCurrentMeal(initialMeal);
    setMealOptions([initialMeal]);
    setRecipe(null);
    setCalories(null);
    setIsRecipeVisible(false);
    setError(null);
    // Auto-load calories for initial meal
    fetchCalories(initialMeal);
  }, [initialMeal]);

  const generateMealOptions = async () => {
    setIsLoadingMeals(true);
    setError(null);
    try {
      const prompt = `Generate 3 alternative ${type} ${title.toLowerCase()} ideas similar to '${currentMeal}'. Provide a JSON object with a 'meals' key containing an array of 3 meal names.`;
      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            meals: {
              type: "array",
              items: { type: "string" },
              description: "A list of 3 meal names."
            }
          },
          required: ["meals"]
        }
      });
      
      if (response && response.meals) {
        const newOptions = [...new Set([currentMeal, ...response.meals])];
        setMealOptions(newOptions);
      } else {
        throw new Error("Failed to get meal suggestions.");
      }
    } catch (e) {
      console.error(e);
      setError("Couldn't generate meals. Please try again.");
    } finally {
      setIsLoadingMeals(false);
    }
  };

  const fetchRecipe = async (mealName) => {
    if (!mealName) return;
    setIsLoadingRecipe(true);
    setError(null);
    setRecipe(null);
    try {
      const prompt = `Provide a simple recipe for '${mealName}'. The output must be a JSON object with two keys: 'ingredients' (an array of strings) and 'preparation' (an array of strings for each step).`;
      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            ingredients: { type: "array", items: { type: "string" } },
            preparation: { type: "array", items: { type: "string" } }
          },
          required: ["ingredients", "preparation"]
        }
      });

      if (response && response.ingredients && response.preparation) {
        setRecipe(response);
      } else {
        throw new Error("Failed to parse recipe from AI response.");
      }
    } catch (e) {
      console.error(e);
      setError("Couldn't fetch recipe. Please try again.");
      setIsRecipeVisible(false);
    } finally {
      setIsLoadingRecipe(false);
    }
  };

  const fetchCalories = async (mealName) => {
    if (!mealName) return;
    setIsLoadingCalories(true);
    try {
      const prompt = `Estimate the calories for a typical serving of '${mealName}'. Return just the number without any text or units.`;
      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            calories: { type: "number", description: "Estimated calories for the meal" }
          },
          required: ["calories"]
        }
      });

      if (response && response.calories) {
        setCalories(response.calories);
      }
    } catch (e) {
      console.error(e);
      setCalories(null);
    } finally {
      setIsLoadingCalories(false);
    }
  };

  const handleMealChange = (newMeal) => {
    setCurrentMeal(newMeal);
    setRecipe(null);
    setCalories(null);
    fetchCalories(newMeal);
    if (isRecipeVisible) {
      fetchRecipe(newMeal);
    }
  };
  
  const handleToggleRecipe = () => {
    const willBeVisible = !isRecipeVisible;
    setIsRecipeVisible(willBeVisible);
    if (willBeVisible && !recipe) {
      fetchRecipe(currentMeal);
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
  };
  const isYoruba = type === 'Yoruba';

  return (
    <motion.div
      variants={cardVariants}
      className="bg-white/50 backdrop-blur-md rounded-xl p-4 md:p-6 flex flex-col border border-black/5"
    >
      <div className="flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-[#4A2A1E]">{title}</h3>
          <div className="flex items-center gap-2">
            <span
              className={`px-3 py-1 text-xs font-semibold rounded-full ${
                isYoruba ? 'bg-[#2C5F2D]/10 text-[#2C5F2D]' : 'bg-[#E54B1A]/10 text-[#E54B1A]'
              }`}
            >
              {type}
            </span>
          </div>
        </div>

        {/* Calories Display */}
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4 text-orange-500" />
          <span className="text-sm font-medium text-gray-700">
            {isLoadingCalories ? (
              <span className="flex items-center gap-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                Loading...
              </span>
            ) : calories ? (
              `${calories} calories`
            ) : (
              'Calories unavailable'
            )}
          </span>
        </div>
        
        <div className="flex items-center gap-2 mb-4">
          <Select onValueChange={handleMealChange} value={currentMeal}>
            <SelectTrigger className="w-full bg-white">
              <SelectValue placeholder="Select a meal" />
            </SelectTrigger>
            <SelectContent>
              {mealOptions.map((meal, index) => (
                <SelectItem key={index} value={meal}>{meal}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" onClick={generateMealOptions} disabled={isLoadingMeals}>
            {isLoadingMeals ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </div>

        <Button
          variant="outline"
          size="sm"
          className="w-full bg-white/50"
          onClick={handleToggleRecipe}
          disabled={isLoadingRecipe}
        >
          {isLoadingRecipe ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <BookOpen className="h-4 w-4 mr-2" />
          )}
          {isRecipeVisible ? 'Hide Recipe' : 'View Recipe'}
        </Button>
        
        {error && <p className="text-red-500 text-xs mt-2 text-center">{error}</p>}
        
        {isRecipeVisible && <RecipeDisplay recipe={recipe?.ingredients} preparation={recipe?.preparation} />}
      </div>
    </motion.div>
  );
}