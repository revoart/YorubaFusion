import React from 'react';
import { motion } from 'framer-motion';

const DayButton = ({ day, dayName, currentDay, onClick }) => {
  const isActive = day === currentDay;
  return (
    <motion.button
      onClick={onClick}
      className={`relative px-3 py-2 text-xs md:text-sm font-semibold rounded-full transition-colors duration-300 ${
        isActive ? 'text-white' : 'text-[#4A2A1E] hover:bg-[#E54B1A]/10'
      }`}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      {isActive && (
        <motion.div
          layoutId="activeDay"
          className="absolute inset-0 bg-gradient-to-r from-[#E54B1A] to-[#FFC93C] rounded-full shadow-lg z-0"
        />
      )}
      <span className="relative z-10">{dayName}</span>
    </motion.button>
  );
};

export default function DayNavigator({ currentDay, onDayChange }) {
  const days = [
    { day: 1, name: 'Monday' },
    { day: 2, name: 'Tuesday' },
    { day: 3, name: 'Wednesday' },
    { day: 4, name: 'Thursday' },
    { day: 5, name: 'Friday' },
    { day: 6, name: 'Saturday' },
    { day: 7, name: 'Sunday' }
  ];

  return (
    <div className="flex justify-center my-8">
      <div className="flex items-center space-x-1 md:space-x-2 bg-[#FDF8F0]/80 backdrop-blur-sm p-2 rounded-full border border-gray-200/50 shadow-sm">
        {days.map(({ day, name }) => (
          <DayButton
            key={day}
            day={day}
            dayName={name}
            currentDay={currentDay}
            onClick={() => onDayChange(day)}
          />
        ))}
      </div>
    </div>
  );
}