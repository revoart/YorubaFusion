import React from 'react';
import { Bookmark, Download, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function ActionButtons({ onFavorite, isFavorite, onDownload, onShare, currentPlan }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="flex justify-center items-center gap-4 mt-8 flex-wrap"
    >
      <Button
        variant="outline"
        className="bg-white/80 border-[#E54B1A]/50 text-[#E54B1A] hover:bg-white hover:text-[#E54B1A] hover:shadow-md transition-all duration-300"
        onClick={onFavorite}
      >
        <Bookmark className={`w-4 h-4 mr-2 ${isFavorite ? 'fill-current text-[#E54B1A]' : ''}`} />
        {isFavorite ? 'Favorited' : 'Favorite this Day'}
      </Button>
      
      <Button
        variant="outline"
        className="bg-white/80 border-[#2C5F2D]/50 text-[#2C5F2D] hover:bg-white hover:text-[#2C5F2D] hover:shadow-md transition-all duration-300"
        onClick={onShare}
      >
        <Share2 className="w-4 h-4 mr-2" />
        Share with Friends
      </Button>
      
      <Button
        className="bg-[#2C5F2D] hover:bg-[#2C5F2D]/90 text-white hover:shadow-md transition-all duration-300"
        onClick={onDownload}
      >
        <Download className="w-4 h-4 mr-2" />
        Download Plan
      </Button>
    </motion.div>
  );
}