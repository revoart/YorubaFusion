import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function RecipeDisplay({ recipe, preparation }) {
  if (!recipe && !preparation) {
    return null;
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="mt-4 overflow-hidden"
      >
        <div className="border-t border-gray-200 pt-4">
          <h4 className="font-semibold text-[#4A2A1E] mb-2">Ingredients</h4>
          <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
            {(recipe || []).map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
          
          <h4 className="font-semibold text-[#4A2A1E] mt-4 mb-2">Preparation</h4>
          <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2">
            {(preparation || []).map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ol>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}