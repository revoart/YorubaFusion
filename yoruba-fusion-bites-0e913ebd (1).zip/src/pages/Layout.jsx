
import React from 'react';
import { UtensilsCrossed } from 'lucide-react';

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-[#FDF8F0] text-[#333333]">
      <div 
        className="absolute inset-0 z-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234A2A1E' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}
      />
      <div className="relative z-10">
        <header className="py-6 px-4 md:px-8 border-b border-[#E54B1A]/20">
          <div className="max-w-6xl mx-auto flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#E54B1A] to-[#FFC93C] rounded-full flex items-center justify-center">
              <UtensilsCrossed className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-[#4A2A1E]">
              Yoruba Fusion Meal Planner
            </h1>
          </div>
        </header>
        <main>{children}</main>
      </div>
    </div>
  );
}
